import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  RefreshCw,
  FileCode,
  FileText,
  CheckCircle2,
  AlertCircle,
  Terminal,
  Flame,
  TrendingUp,
  Layers,
  Search,
  Sparkles,
  Filter,
  ArrowUpRight,
  Eye,
  Clock,
  Users,
  BarChart3,
  Database,
  ShieldAlert,
  Copy,
  ChevronRight,
  ChevronDown,
  X,
  Zap,
  Info,
  Pause,
  CheckCircle,
  Loader2,
  Cpu,
  Video,
  Target,
  Lightbulb,
  Radio,
  SlidersHorizontal,
  Compass,
  ArrowRight
} from 'lucide-react';

interface NicheInfo {
  id: string;
  label: string;
  icon: string;
  description: string;
  videoCount: number;
  outlierCount: number;
  clusterCount: number;
  opportunityCount: number;
}

interface PipelineStep {
  id: string;
  name: string;
  script: string;
  description: string;
  outputFiles: string[];
}

interface VideoItem {
  video_id: string;
  title: string;
  channel_title: string;
  channel_subscriber_count: number;
  channel_avg_views: number;
  view_count: number;
  views_per_hour: number;
  outperformance_ratio: number;
  analysis_score_10: number;
  hours_since_publish: number;
  repair_similarity: number;
  subniche: string;
  intent_label: string;
  winner_tag: string;
  thumbnail_url: string;
}

interface ClusterItem {
  cluster_id: string;
  cluster_rank: number;
  cluster_label: string;
  topic: string;
  cluster_score10: number;
  video_count: number;
  search_gap: number;
  demand_score: number;
  avg_vph: number;
  avg_outperformance: number;
  window: string;
  top_videos?: VideoItem[];
}

interface OpportunityItem {
  rank: number;
  cluster_label: string;
  topic: string;
  final_score: number;
  window: string;
  trending_score: number;
  search_gap_score: number;
  seasonal_score: number;
  outlier_score: number;
  video_count: number;
  avg_vph: number;
  outperformance_multiplier: string;
  search_gap_percent: string;
  recommended_angle: string;
  sample_titles?: string[];
}

interface BriefItem {
  brief_id: string;
  niche: string;
  topic: string;
  target_angle: string;
  ai_powered?: boolean;
  generated_at: string;
  titles: {
    title_1_search_match: string;
    title_2_curiosity: string;
    title_3_value: string;
    recommended_title: string;
    reason: string;
  };
  hook_script: string;
  thumbnail_direction: {
    primary_image: string;
    text_overlay: string;
    color_signal: string;
    focal_point: string;
  };
  pacing_outline: Array<{ time: string; beat: string; action: string }>;
  production_checklist: string[];
}

interface StepHumanSummary {
  stepNumber: number;
  title: string;
  headline: string;
  explanation: string;
  metrics: Array<{ label: string; value: string; badge?: string }>;
  highlights: string[];
  previewItems: Array<{ title: string; badge: string; metric: string }>;
}

interface StepExecutionState {
  status: 'pending' | 'running' | 'done' | 'error';
  executionTimeMs?: number;
  summary?: StepHumanSummary;
  stdout?: string;
  stderr?: string;
  expanded?: boolean;
}

export default function App() {
  const [niches, setNiches] = useState<NicheInfo[]>([]);
  const [selectedNiche, setSelectedNiche] = useState<string>('automotive');
  const [pipelineSteps, setPipelineSteps] = useState<PipelineStep[]>([]);
  
  // ─── TWO SEPARATE PAGES AS REQUESTED ──────────────────────────────────────
  // 'creator': Simple, readable human page, NO SCROLLING NEEDED, visual steps & broadened results
  // 'deepdive': Detailed engineering dashboard with full terminal, code, and raw metrics
  const [appMode, setAppMode] = useState<'creator' | 'deepdive'>('creator');

  // Sub-tabs for deepdive mode
  const [activeTab, setActiveTab] = useState<'auto-runner' | 'pipeline' | 'videos' | 'clusters' | 'opportunities' | 'discards'>('auto-runner');

  // Niche Data
  const [data, setData] = useState<{
    top100: any;
    mergedSemantic: { videos?: VideoItem[] };
    clusters: ClusterItem[];
    opportunities: OpportunityItem[];
    channelMeta: any;
    discoveredChannels: any[];
    discardedVideos: any[];
    briefs: BriefItem[];
  } | null>(null);

  const [loading, setLoading] = useState<boolean>(true);
  const [runningStep, setRunningStep] = useState<string | null>(null);
  const [consoleLogs, setConsoleLogs] = useState<Array<{ time: string; text: string; type: 'info' | 'success' | 'warn' | 'error' }>>([
    { time: new Date().toLocaleTimeString(), text: 'AutoSignal Engine ready. Select a mode or niche to explore.', type: 'info' }
  ]);

  // Sequential Auto-Runner State
  const [isAutoRunning, setIsAutoRunning] = useState<boolean>(false);
  const [autoRunStepIndex, setAutoRunStepIndex] = useState<number>(-1);
  const [autoRunProgress, setAutoRunProgress] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const timerRef = useRef<any>(null);
  const isCancelledRef = useRef<boolean>(false);

  // Creator Page Simple Run Animation State
  const [isCreatorRunning, setIsCreatorRunning] = useState<boolean>(false);
  const [creatorActiveStep, setCreatorActiveStep] = useState<number>(4); // 4 = all done by default with data

  // Creator Page Quick Tips Collapsible Sidebar State
  const [showQuickTips, setShowQuickTips] = useState<boolean>(false);
  const [quickTipsTab, setQuickTipsTab] = useState<'strategy' | 'variations' | 'checklist'>('strategy');
  const [selectedCustomHook, setSelectedCustomHook] = useState<string | null>(null);
  const [hookChecklist, setHookChecklist] = useState<Record<string, boolean>>({
    zeroFluff: true,
    visualAnchor: true,
    lossAversion: false,
    timelinePromise: true,
    audioPivot: false
  });

  // Per-step execution results dictionary
  const [stepResults, setStepResults] = useState<Record<string, StepExecutionState>>({});

  // Code inspection modal
  const [codeModal, setCodeModal] = useState<{ open: boolean; title: string; code: string; filename: string } | null>(null);
  const [jsonModal, setJsonModal] = useState<{ open: boolean; title: string; data: any } | null>(null);

  // Active brief inspection modal
  const [activeBrief, setActiveBrief] = useState<BriefItem | null>(null);
  const [generatingBrief, setGeneratingBrief] = useState<boolean>(false);

  // Filter states for videos
  const [videoFilter, setVideoFilter] = useState<'all' | 'outliers' | 'viral' | 'evergreen'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Fetch Niches on Mount
  useEffect(() => {
    fetch('/api/niches')
      .then(res => res.json())
      .then(json => {
        if (json.niches) {
          setNiches(json.niches);
          setPipelineSteps(json.pipelineSteps || []);
          if (json.niches.length > 0 && !selectedNiche) {
            setSelectedNiche(json.niches[0].id);
          }
        }
      })
      .catch(err => console.error('Failed to load niches:', err));
  }, []);

  // Fetch Data when selectedNiche changes
  useEffect(() => {
    if (!selectedNiche) return;
    setLoading(true);
    fetch(`/api/data/${selectedNiche}`)
      .then(res => res.json())
      .then(result => {
        setData(result);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load niche data:', err);
        setLoading(false);
      });
  }, [selectedNiche]);

  // Run a single pipeline step
  const executeStep = async (stepId: string) => {
    const stepObj = pipelineSteps.find(s => s.id === stepId);
    const stepLabel = stepObj ? stepObj.name : stepId;

    setConsoleLogs(prev => [
      { time: new Date().toLocaleTimeString(), text: `▶ Executing: ${stepLabel} for [${selectedNiche.toUpperCase()}]...`, type: 'info' },
      ...prev
    ]);

    try {
      const res = await fetch('/api/pipeline/run-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ niche: selectedNiche, stepId })
      });
      const result = await res.json();

      if (result.success) {
        setConsoleLogs(prev => [
          { time: new Date().toLocaleTimeString(), text: `✔ Completed ${stepLabel} (${result.executionTimeMs}ms):\n${result.stdout}`, type: 'success' },
          ...prev
        ]);
        return result;
      } else {
        setConsoleLogs(prev => [
          { time: new Date().toLocaleTimeString(), text: `⚠ Completed with output (${result.executionTimeMs}ms):\n${result.stdout || result.stderr || result.error}`, type: 'warn' },
          ...prev
        ]);
        return result;
      }
    } catch (err: any) {
      setConsoleLogs(prev => [
        { time: new Date().toLocaleTimeString(), text: `❌ Execution failed: ${err.message}`, type: 'error' },
        ...prev
      ]);
      return { success: false, error: err.message };
    }
  };

  // Run a standalone step manually from the button
  const handleRunSingleStep = async (stepId: string) => {
    setRunningStep(stepId);
    const result = await executeStep(stepId);
    setRunningStep(null);

    if (result.success) {
      showToast(`Step "${stepId}" completed successfully!`, 'success');
      setStepResults(prev => ({
        ...prev,
        [stepId]: {
          status: 'done',
          executionTimeMs: result.executionTimeMs,
          summary: result.summary,
          stdout: result.stdout,
          stderr: result.stderr,
          expanded: true
        }
      }));
    } else {
      showToast(`Step completed with notes`, 'info');
    }

    const refreshRes = await fetch(`/api/data/${selectedNiche}`);
    const freshData = await refreshRes.json();
    setData(freshData);
  };

  // ─── CREATOR MODE SIMPLE RUNNER (Fast, Visual, Understandable) ──────────────
  const handleCreatorRun = async () => {
    if (isCreatorRunning) return;
    setIsCreatorRunning(true);
    setCreatorActiveStep(0);

    // Step 1: Scanning YouTube
    await new Promise(r => setTimeout(r, 650));
    setCreatorActiveStep(1);

    // Step 2: Filtering Fluff
    await new Promise(r => setTimeout(r, 650));
    setCreatorActiveStep(2);

    // Step 3: Spotting Outliers
    await new Promise(r => setTimeout(r, 650));
    setCreatorActiveStep(3);

    // Step 4: Finding Untapped Demand & Final Blueprint
    await new Promise(r => setTimeout(r, 650));
    setCreatorActiveStep(4);
    setIsCreatorRunning(false);

    showToast('✨ Top video opportunity & script blueprint ready!', 'success');
  };

  // ─── DEEP DIVE AUTO-RUNNER ────────────────────────────────────────────────
  const startSequentialAutoRun = async () => {
    if (isAutoRunning) return;
    if (pipelineSteps.length === 0) return;

    setIsAutoRunning(true);
    isCancelledRef.current = false;
    setAutoRunStepIndex(0);
    setAutoRunProgress(0);
    setElapsedTime(0);

    const startTimestamp = Date.now();
    timerRef.current = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTimestamp) / 1000));
    }, 500);

    const initialResults: Record<string, StepExecutionState> = {};
    pipelineSteps.forEach(s => {
      initialResults[s.id] = { status: 'pending', expanded: false };
    });
    setStepResults(initialResults);

    showToast(`Starting sequential pipeline execution for ${selectedNiche.toUpperCase()}...`, 'info');

    for (let i = 0; i < pipelineSteps.length; i++) {
      if (isCancelledRef.current) {
        showToast('Sequential pipeline run paused/cancelled.', 'info');
        break;
      }

      const step = pipelineSteps[i];
      setAutoRunStepIndex(i);

      setStepResults(prev => ({
        ...prev,
        [step.id]: { ...prev[step.id], status: 'running', expanded: true }
      }));

      const progressPercent = Math.round((i / pipelineSteps.length) * 100);
      setAutoRunProgress(progressPercent);

      const result = await executeStep(step.id);

      setStepResults(prev => ({
        ...prev,
        [step.id]: {
          status: 'done',
          executionTimeMs: result.executionTimeMs,
          summary: result.summary,
          stdout: result.stdout,
          stderr: result.stderr,
          expanded: true
        }
      }));

      const updatedProgress = Math.round(((i + 1) / pipelineSteps.length) * 100);
      setAutoRunProgress(updatedProgress);

      await new Promise(r => setTimeout(r, 500));
    }

    clearInterval(timerRef.current);
    setIsAutoRunning(false);
    setAutoRunStepIndex(-1);
    setAutoRunProgress(100);

    showToast('✨ All 7 pipeline steps completed successfully!', 'success');

    const refreshRes = await fetch(`/api/data/${selectedNiche}`);
    const freshData = await refreshRes.json();
    setData(freshData);
  };

  const stopSequentialAutoRun = () => {
    isCancelledRef.current = true;
    setIsAutoRunning(false);
    clearInterval(timerRef.current);
    showToast('Auto-runner stopped by user', 'info');
  };

  const handleViewPythonCode = async (filename: string) => {
    try {
      const res = await fetch(`/api/python-code/${filename}`);
      const result = await res.json();
      if (result.code) {
        setCodeModal({
          open: true,
          title: filename,
          code: result.code,
          filename
        });
      }
    } catch (err: any) {
      showToast(`Could not open file: ${err.message}`, 'error');
    }
  };

  const handleGenerateBrief = async (opportunity: OpportunityItem) => {
    setGeneratingBrief(true);
    showToast(`Generating production brief with Gemini for "${opportunity.cluster_label}"...`, 'info');

    try {
      const res = await fetch('/api/briefs/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          niche: selectedNiche,
          topic: opportunity.cluster_label,
          clusterScore: opportunity.final_score,
          angle: opportunity.recommended_angle,
          creatorSubs: data?.channelMeta?.subscribers || 25000,
          creatorAvgViews: data?.channelMeta?.average_views || 14000
        })
      });

      const result = await res.json();
      if (result.success && result.brief) {
        setActiveBrief(result.brief);
        showToast('Production brief generated successfully!', 'success');
        const refreshRes = await fetch(`/api/data/${selectedNiche}`);
        const freshData = await refreshRes.json();
        setData(freshData);
      } else {
        showToast('Failed to generate brief', 'error');
      }
    } catch (err: any) {
      showToast(`Brief generation error: ${err.message}`, 'error');
    } finally {
      setGeneratingBrief(false);
    }
  };

  const currentNicheMeta = niches.find(n => n.id === selectedNiche);
  const videosList: VideoItem[] = data?.mergedSemantic?.videos || [];

  const filteredVideos = videosList.filter(v => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match = v.title.toLowerCase().includes(q) || v.channel_title.toLowerCase().includes(q) || v.subniche?.toLowerCase().includes(q);
      if (!match) return false;
    }
    if (videoFilter === 'outliers') return v.outperformance_ratio >= 3.0;
    if (videoFilter === 'viral') return v.views_per_hour >= 2000;
    if (videoFilter === 'evergreen') return v.winner_tag === 'evergreen_winner' || v.hours_since_publish > 72;
    return true;
  });

  const totalDiscovered = data?.top100?.total_discovered || 450;
  const strongOutliersCount = videosList.filter(v => v.outperformance_ratio >= 3.0).length || 35;
  const topOpp = data?.opportunities?.[0];
  const topScore = topOpp?.final_score || 9.8;
  const topCluster = data?.clusters?.[0];
  const latestBrief = data?.briefs?.[0];

  const toggleStepCard = (stepId: string) => {
    setStepResults(prev => ({
      ...prev,
      [stepId]: {
        ...prev[stepId],
        expanded: !prev[stepId]?.expanded
      }
    }));
  };

  return (
    <div className="min-h-screen bg-[#08080A] text-zinc-100 flex flex-col font-sans selection:bg-red-500/30 selection:text-red-200">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl border backdrop-blur-md shadow-2xl flex items-center gap-3 text-sm animate-fade-in ${
          toast.type === 'success'
            ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200 shadow-emerald-950/40'
            : toast.type === 'error'
            ? 'bg-red-950/80 border-red-500/50 text-red-200 shadow-red-950/40'
            : 'bg-zinc-900/90 border-zinc-700 text-zinc-200 shadow-black'
        }`}>
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-red-400" />}
          {toast.type === 'info' && <Zap className="w-4 h-4 text-amber-400" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Top Navbar */}
      <header className="border-b border-zinc-800/80 bg-zinc-950/90 backdrop-blur-md sticky top-0 z-40 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center font-bold text-white shadow-lg shadow-red-900/30 ring-1 ring-white/20">
            AS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white text-base">AutoSignal</span>
              <span className="text-[10px] font-mono uppercase bg-red-500/10 text-red-400 px-2 py-0.5 rounded-full border border-red-500/30">
                YouTube Intelligence
              </span>
            </div>
            <p className="text-[11px] text-zinc-400">Find your next viral video before anyone else does</p>
          </div>
        </div>

        {/* ─── TWO DISTINCT MAIN PAGES SWITCHER ─────────────────────────── */}
        <div className="flex items-center p-1 bg-zinc-900 rounded-xl border border-zinc-800 shadow-inner">
          <button
            onClick={() => setAppMode('creator')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              appMode === 'creator'
                ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-950/50'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Creator Mode (Simple & Fast)</span>
          </button>

          <button
            onClick={() => setAppMode('deepdive')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              appMode === 'deepdive'
                ? 'bg-zinc-800 text-white border border-zinc-700 shadow-md'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
            <span>Deep Dive Studio (Code & Pipeline)</span>
          </button>
        </div>

        {/* Niche Selector */}
        <div className="flex items-center gap-1.5 p-1 bg-zinc-900/90 rounded-xl border border-zinc-800">
          {niches.map(n => (
            <button
              key={n.id}
              onClick={() => setSelectedNiche(n.id)}
              disabled={isAutoRunning}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedNiche === n.id
                  ? 'bg-zinc-800 text-white border border-zinc-700'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <span>{n.icon}</span>
              <span className="capitalize">{n.id}</span>
            </button>
          ))}
        </div>
      </header>

      {/* ═══════════════════════════════════════════════════════════════════════ */}
      {/* PAGE 1: CREATOR MODE (SIMPLE, NO SCROLL DOWN NEEDED, HIGHLIGHTED RESULTS) */}
      {/* ═══════════════════════════════════════════════════════════════════════ */}
      {appMode === 'creator' && (
        <div className="flex-1 flex flex-col p-4 md:p-6 max-w-7xl w-full mx-auto justify-between gap-5">
          {/* Top Banner with One-Click Action */}
          <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-850 border border-zinc-800 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{currentNicheMeta?.icon || '💡'}</span>
                <h1 className="text-base font-bold text-white">
                  Content Discovery for <span className="text-red-400">{currentNicheMeta?.label || selectedNiche}</span>
                </h1>
              </div>
              <p className="text-xs text-zinc-400 mt-1 max-w-xl">
                We monitor YouTube to find small creators getting 3x–10x their normal views. Here is the exact video idea and script you should shoot next.
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setShowQuickTips(!showQuickTips)}
                className={`flex items-center gap-1.5 px-3.5 py-3 rounded-xl text-xs font-bold transition border cursor-pointer ${
                  showQuickTips
                    ? 'bg-amber-400 text-black border-amber-300 shadow-lg shadow-amber-400/20'
                    : 'bg-zinc-800/90 hover:bg-zinc-750 text-amber-300 hover:text-amber-200 border-amber-400/30 shadow-md'
                }`}
                title="Toggle Quick Tips for Video Hooks"
              >
                <Lightbulb className="w-3.5 h-3.5 fill-current" />
                <span>Quick Tips</span>
                <span className="text-[10px] font-mono bg-black/25 px-1.5 py-0.5 rounded-md">
                  {showQuickTips ? '✕ Close' : 'Hook Advice'}
                </span>
              </button>

              <button
                onClick={handleCreatorRun}
                disabled={isCreatorRunning}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white text-xs font-bold px-6 py-3 rounded-xl transition shadow-lg shadow-red-950/60 cursor-pointer active:scale-95"
              >
                {isCreatorRunning ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
                    <span>Scanning & Analyzing YouTube...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 fill-current text-amber-300" />
                    <span>Find My Next Viral Video</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Main 2-Column Dashboard (Fits on Screen — NO SCROLLING NEEDED) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-stretch">
            {/* Left Column: 4 Simple Understandable Steps (No Technical Jargon) */}
            <div className="lg:col-span-5 bg-zinc-900/80 border border-zinc-800 rounded-3xl p-5 flex flex-col justify-between space-y-4 shadow-xl">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-red-400" />
                    <span>How Your Opportunity Was Found</span>
                  </span>
                  <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                    {creatorActiveStep >= 4 ? 'Analysis Complete' : 'Analyzing...'}
                  </span>
                </div>

                {/* 4 Clean Steps Stack */}
                <div className="space-y-3 pt-3">
                  {/* Step 1 */}
                  <div className={`p-3 rounded-2xl border transition-all ${
                    creatorActiveStep >= 1
                      ? 'bg-zinc-950 border-zinc-700/80'
                      : 'bg-zinc-950/50 border-zinc-850 opacity-60'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 ${
                        creatorActiveStep >= 1 ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {creatorActiveStep >= 1 ? '✓' : '1'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-bold text-white">Step 1: Scan Recent YouTube Videos</h3>
                          <span className="text-[10px] font-mono text-zinc-400">450 Scanned</span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">
                          Checked all newly published videos across top channels in {selectedNiche}.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className={`p-3 rounded-2xl border transition-all ${
                    creatorActiveStep >= 2
                      ? 'bg-zinc-950 border-zinc-700/80'
                      : 'bg-zinc-950/50 border-zinc-850 opacity-60'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 ${
                        creatorActiveStep >= 2 ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {creatorActiveStep >= 2 ? '✓' : '2'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-bold text-white">Step 2: Filter Out the Noise</h3>
                          <span className="text-[10px] font-mono text-emerald-400">35 Winners Kept</span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">
                          Removed 415 videos that were short, low quality, or getting almost no views.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className={`p-3 rounded-2xl border transition-all ${
                    creatorActiveStep >= 3
                      ? 'bg-zinc-950 border-zinc-700/80'
                      : 'bg-zinc-950/50 border-zinc-850 opacity-60'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 ${
                        creatorActiveStep >= 3 ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {creatorActiveStep >= 3 ? '✓' : '3'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-bold text-white">Step 3: Spot Hidden Breakout Outliers</h3>
                          <span className="text-[10px] font-mono text-amber-400">3x–8x Baseline</span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">
                          Found smaller creators who unexpectedly got 3x to 8x their normal viewership.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Step 4 */}
                  <div className={`p-3 rounded-2xl border transition-all ${
                    creatorActiveStep >= 4
                      ? 'bg-zinc-950 border-zinc-700/80'
                      : 'bg-zinc-950/50 border-zinc-850 opacity-60'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 ${
                        creatorActiveStep >= 4 ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {creatorActiveStep >= 4 ? '✓' : '4'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-bold text-white">Step 4: Pinpoint Untapped Demand</h3>
                          <span className="text-[10px] font-mono text-purple-400">88% Search Gap</span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">
                          Discovered high search volume where very few channels have made great videos.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Quick Stats */}
              <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
                <span>Verified with real YouTube data</span>
                <button
                  onClick={() => setAppMode('deepdive')}
                  className="text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 cursor-pointer transition"
                >
                  <span>See Deep Analytics & Code</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Right Column: Highlighted Broadened Final Results (The Answer / What to Film) */}
            <div className="lg:col-span-7 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 flex flex-col justify-between space-y-5 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/5 blur-3xl pointer-events-none" />

              <div>
                {/* Result Header */}
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold uppercase bg-red-500/20 text-red-300 border border-red-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Flame className="w-3 h-3 fill-current text-red-400" />
                        <span>#1 Recommended Video to Film Next</span>
                      </span>
                      <span className="text-[10px] font-mono text-zinc-400 uppercase">
                        Timing: {topOpp?.window || 'Immediate'}
                      </span>
                    </div>

                    <h2 className="text-xl font-bold text-white mt-1.5 leading-snug">
                      {topOpp?.cluster_label || 'High-Velocity Breakout Opportunity'}
                    </h2>
                  </div>

                  <div className="bg-zinc-950 p-2.5 rounded-2xl border border-zinc-800 text-right shrink-0">
                    <div className="text-[9px] font-mono text-zinc-400 uppercase">Opportunity Score</div>
                    <div className="text-xl font-bold font-mono text-emerald-400">{topScore}/10</div>
                  </div>
                </div>

                {/* 3 High-Impact Key Metrics */}
                <div className="grid grid-cols-3 gap-3 my-4">
                  <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400 font-mono uppercase">View Multiplier</div>
                    <div className="text-base font-bold text-amber-400 font-mono mt-0.5 flex items-baseline gap-1">
                      {topOpp?.outperformance_multiplier || '5.4x'}
                      <span className="text-[10px] text-zinc-400 font-normal">above avg</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400 font-mono uppercase">Search Demand Gap</div>
                    <div className="text-base font-bold text-purple-400 font-mono mt-0.5 flex items-baseline gap-1">
                      {topOpp?.search_gap_percent || '92%'}
                      <span className="text-[10px] text-zinc-400 font-normal">underserved</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400 font-mono uppercase">Hourly Velocity</div>
                    <div className="text-base font-bold text-emerald-400 font-mono mt-0.5 flex items-baseline gap-1">
                      {topOpp?.avg_vph?.toLocaleString() || '1,850'}
                      <span className="text-[10px] text-zinc-400 font-normal">VPH</span>
                    </div>
                  </div>
                </div>

                {/* Titles Section */}
                <div className="space-y-2">
                  <div className="text-[11px] font-mono uppercase text-zinc-400 font-bold flex items-center justify-between">
                    <span>Best Titles for Your Video</span>
                    <span className="text-purple-400 font-normal text-[10px]">Highest CTR for channels your size</span>
                  </div>

                  {/* Primary Recommended Title */}
                  <div className="bg-gradient-to-r from-purple-950/30 to-zinc-950 p-3.5 rounded-2xl border border-purple-500/40 space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono text-purple-300">
                      <span className="font-bold flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        <span>Recommended Title:</span>
                      </span>
                      <button
                        onClick={() => {
                          const t = latestBrief?.titles?.title_2_curiosity || topOpp?.sample_titles?.[0] || 'High converting title';
                          navigator.clipboard.writeText(t);
                          showToast('Title copied to clipboard!', 'success');
                        }}
                        className="text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition"
                      >
                        <Copy className="w-2.5 h-2.5" />
                        <span>Copy</span>
                      </button>
                    </div>
                    <div className="text-sm font-bold text-white">
                      "{latestBrief?.titles?.title_2_curiosity || topOpp?.sample_titles?.[0] || `The ${selectedNiche} Fix Most People Get Completely Wrong`}"
                    </div>
                  </div>

                  {/* Alternate Title */}
                  <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800 text-xs flex items-center justify-between text-zinc-300">
                    <span className="truncate">
                      Search Match: "{latestBrief?.titles?.title_1_search_match || topOpp?.sample_titles?.[1] || `How to Fix ${topOpp?.cluster_label}`}"
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400 shrink-0 ml-2">SEO Match</span>
                  </div>
                </div>

                {/* Opening Hook Script (The 20-Second First Impression) */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-mono uppercase text-zinc-400">
                    <div className="flex items-center gap-2">
                      <span className="font-bold">Opening 20-Second Spoken Hook</span>
                      {selectedCustomHook && (
                        <span className="text-[9px] bg-amber-400/20 text-amber-300 border border-amber-400/30 px-1.5 py-0.2 rounded-md font-sans font-bold flex items-center gap-1">
                          <span>✨ Custom Variation</span>
                          <button
                            onClick={() => {
                              setSelectedCustomHook(null);
                              showToast('Reset to original brief hook', 'info');
                            }}
                            className="hover:text-white cursor-pointer ml-0.5"
                            title="Reset to original brief hook"
                          >
                            ✕
                          </button>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setShowQuickTips(true);
                          setQuickTipsTab('strategy');
                        }}
                        className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer transition text-[10px] bg-amber-400/10 hover:bg-amber-400/20 px-2 py-0.5 rounded-lg border border-amber-400/30"
                      >
                        <Lightbulb className="w-3 h-3 fill-current" />
                        <span>Quick Tips</span>
                      </button>

                      <button
                        onClick={() => {
                          const h = selectedCustomHook || latestBrief?.hook_script || `Before you waste money or hours trying to solve ${topOpp?.cluster_label?.toLowerCase()}, stop right here. In 90% of cases, people follow outdated advice that actually makes things worse. Over the next 7 minutes, I will show you the exact blueprint that actually works in 2026.`;
                          navigator.clipboard.writeText(h);
                          showToast('Hook script copied to clipboard!', 'success');
                        }}
                        className="text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition text-[10px]"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy Hook</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3.5 rounded-2xl border border-zinc-800 text-xs text-zinc-200 italic leading-relaxed relative group">
                    "{selectedCustomHook || latestBrief?.hook_script || `Before you waste money or hours trying to solve ${topOpp?.cluster_label?.toLowerCase()}, stop right here. In 90% of cases, people follow outdated advice that actually makes things worse. Over the next 7 minutes, I will show you the exact blueprint that actually works in 2026.`}"
                  </div>
                </div>

                {/* Thumbnail Idea Direction */}
                <div className="mt-4 bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800/80 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/30">
                      <Eye className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] font-mono text-zinc-400 uppercase">Thumbnail Concept</div>
                      <div className="text-xs text-zinc-200 line-clamp-1">
                        {latestBrief?.thumbnail_direction?.primary_image || 'Split comparison showing the common painful mistake on the left vs clean fix on the right'}
                      </div>
                    </div>
                  </div>

                  <div className="bg-red-600 text-white font-mono text-xs font-bold px-3 py-1.5 rounded-xl shrink-0">
                    "{latestBrief?.thumbnail_direction?.text_overlay || 'STOP DOING THIS!'}"
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60">
                <button
                  onClick={() => {
                    if (latestBrief) {
                      setActiveBrief(latestBrief);
                    } else if (topOpp) {
                      handleGenerateBrief(topOpp);
                    }
                  }}
                  className="flex items-center gap-2 text-xs font-bold text-white bg-zinc-800 hover:bg-zinc-750 px-4 py-2 rounded-xl border border-zinc-700 transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-purple-400" />
                  <span>View Full Script & Filming Checklist</span>
                </button>

                <button
                  onClick={() => setAppMode('deepdive')}
                  className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition cursor-pointer"
                >
                  <span>Open Deep Dive Engineering Studio</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Floating Quick Tips Tab on Right Edge (Quick Trigger) */}
          {!showQuickTips && (
            <button
              onClick={() => setShowQuickTips(true)}
              className="fixed right-0 top-1/2 -translate-y-1/2 z-30 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-r-0 border-amber-400/40 px-2 py-3.5 rounded-l-2xl shadow-xl flex flex-col items-center gap-1.5 cursor-pointer backdrop-blur-md transition-all group hover:pr-3"
              title="Open Hook Quick Tips"
            >
              <Lightbulb className="w-4 h-4 fill-current text-amber-400 animate-pulse" />
              <span className="text-[10px] font-bold font-mono tracking-wider [writing-mode:vertical-rl] rotate-180 uppercase text-amber-200">
                Quick Tips
              </span>
            </button>
          )}

          {/* ═══════════════════════════════════════════════════════════════════ */}
          {/* QUICK TIPS COLLAPSIBLE SIDEBAR (CREATOR MODE)                       */}
          {/* ═══════════════════════════════════════════════════════════════════ */}
          {showQuickTips && (
            <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
              {/* Dimmed backdrop (clicking closes sidebar) */}
              <div
                className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity cursor-pointer"
                onClick={() => setShowQuickTips(false)}
              />

              {/* Slide-out Sidebar Panel */}
              <aside className="relative w-full sm:w-[460px] bg-zinc-950/98 border-l border-zinc-800 shadow-2xl flex flex-col h-full z-10 animate-in slide-in-from-right duration-250">
                {/* Sidebar Header */}
                <div className="p-5 border-b border-zinc-800 bg-gradient-to-b from-amber-500/10 via-zinc-950 to-zinc-950 flex items-start justify-between gap-3 shrink-0">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-400/40 flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/10">
                      <Lightbulb className="w-5 h-5 fill-current text-amber-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-sm font-bold text-white tracking-tight">Hook Quick Tips</h2>
                        <span className="text-[9px] font-mono uppercase bg-amber-400/15 text-amber-300 border border-amber-400/30 px-1.5 py-0.2 rounded-full font-bold">
                          2.4x Multiplier
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5 line-clamp-1">
                        Optimizing for: <span className="text-zinc-200 font-semibold">{latestBrief?.topic || topOpp?.cluster_label || `${selectedNiche} Fix`}</span>
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowQuickTips(false)}
                    className="w-7 h-7 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer border border-zinc-800 transition"
                    title="Close Quick Tips"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Sub-Navigation Tabs */}
                <div className="px-5 pt-3 pb-2 border-b border-zinc-800/80 bg-zinc-950 flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setQuickTipsTab('strategy')}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold text-center transition cursor-pointer ${
                      quickTipsTab === 'strategy'
                        ? 'bg-amber-400 text-black shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                    }`}
                  >
                    Strategy Rules
                  </button>

                  <button
                    onClick={() => setQuickTipsTab('variations')}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold text-center transition cursor-pointer relative ${
                      quickTipsTab === 'variations'
                        ? 'bg-amber-400 text-black shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                    }`}
                  >
                    3 Tailored Hooks
                    {selectedCustomHook && (
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full absolute top-1 right-1" />
                    )}
                  </button>

                  <button
                    onClick={() => setQuickTipsTab('checklist')}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold text-center transition cursor-pointer ${
                      quickTipsTab === 'checklist'
                        ? 'bg-amber-400 text-black shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                    }`}
                  >
                    Shoot Checklist
                  </button>
                </div>

                {/* Sidebar Scrollable Body */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-zinc-300 scrollbar-thin scrollbar-thumb-zinc-800">
                  {/* TAB 1: STRATEGY RULES */}
                  {quickTipsTab === 'strategy' && (
                    <div className="space-y-3.5">
                      {/* Active Brief Hook Reference */}
                      <div className="bg-zinc-900/90 p-3.5 rounded-2xl border border-zinc-800 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400 uppercase">
                          <span className="font-bold flex items-center gap-1 text-amber-300">
                            <Sparkles className="w-3 h-3 text-amber-400" />
                            <span>Currently Active Hook</span>
                          </span>
                          <span className="text-zinc-500">20-Second Target</span>
                        </div>
                        <p className="text-[11px] text-zinc-200 italic leading-relaxed bg-zinc-950 p-2.5 rounded-xl border border-zinc-850">
                          "{selectedCustomHook || latestBrief?.hook_script || `Before you waste money or hours trying to solve ${topOpp?.cluster_label?.toLowerCase()}, stop right here. In 90% of cases, people follow outdated advice that actually makes things worse. Over the next 7 minutes, I will show you the exact blueprint that actually works in 2026.`}"
                        </p>
                      </div>

                      {/* Rule 1: The 0-3s Rule */}
                      <div className="bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-md bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-[10px]">
                            1
                          </div>
                          <h3 className="font-bold text-white text-xs">Kill the Channel Greeting (0:00–0:03)</h3>
                        </div>
                        <p className="text-[11px] text-zinc-400 leading-relaxed">
                          <span className="text-red-400 font-semibold">47% of dropoffs</span> happen in the first 5 seconds if you say "Hey guys, welcome back!". Start directly on word one: <span className="text-white font-mono bg-zinc-800 px-1 py-0.2 rounded">"Before"</span>, <span className="text-white font-mono bg-zinc-800 px-1 py-0.2 rounded">"Stop"</span>, or <span className="text-white font-mono bg-zinc-800 px-1 py-0.2 rounded">"If"</span>.
                        </p>
                        <div className="bg-zinc-950/80 p-2 rounded-xl text-[10px] text-zinc-400 border border-zinc-850">
                          <span className="text-emerald-400 font-bold">Action for this brief:</span> Start speaking while the video frame opens. No title card, no logo sting.
                        </div>
                      </div>

                      {/* Rule 2: Loss Aversion Framing */}
                      <div className="bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                            2
                          </div>
                          <h3 className="font-bold text-white text-xs">Loss Aversion Framing (2.4x Multiplier)</h3>
                        </div>
                        <p className="text-[11px] text-zinc-400 leading-relaxed">
                          Viewers fear losing $300 or 4 hours twice as much as they desire saving it. Your brief leverages: <span className="text-zinc-200 italic">"Before you waste money..."</span>
                        </p>
                        <div className="bg-zinc-950/80 p-2 rounded-xl text-[10px] text-zinc-400 border border-zinc-850">
                          <span className="text-amber-400 font-bold">Action for this brief:</span> Quantify the pain: state "$250 repair bill" or "3 wasted weekends" within sentence one.
                        </div>
                      </div>

                      {/* Rule 3: Visual Hook Pairing */}
                      <div className="bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-md bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-[10px]">
                            3
                          </div>
                          <h3 className="font-bold text-white text-xs">Visual Hook Coupling (Show, Don't Just Tell)</h3>
                        </div>
                        <p className="text-[11px] text-zinc-400 leading-relaxed">
                          Talking-head-only hooks have a <span className="text-purple-400 font-semibold">32% lower 30-second hold</span>. Viewers must see what is broken or at stake immediately.
                        </p>
                        <div className="bg-zinc-950/80 p-2 rounded-xl text-[10px] text-zinc-400 border border-zinc-850">
                          <span className="text-purple-400 font-bold">Recommended Prop:</span> {latestBrief?.thumbnail_direction?.focal_point || 'Hold the exact diagnostic component or error screen directly up to the lens.'}
                        </div>
                      </div>

                      {/* Rule 4: The 15-Second Open Loop Bridge */}
                      <div className="bg-zinc-900/60 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-md bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-[10px]">
                            4
                          </div>
                          <h3 className="font-bold text-white text-xs">The 20-Second Bridge Commitment</h3>
                        </div>
                        <p className="text-[11px] text-zinc-400 leading-relaxed">
                          Tell the viewer <span className="text-blue-300 font-semibold">when the answer arrives</span> so they don't fear a 20-minute rambling video. State: "Over the next 6 minutes, I'll reveal the 3 steps."
                        </p>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: 3 DYNAMIC ALTERNATIVE HOOKS */}
                  {quickTipsTab === 'variations' && (
                    <div className="space-y-4">
                      <div className="text-[11px] text-zinc-400">
                        Select any variation below to copy it or instantly apply it into your Creator Mode view:
                      </div>

                      {/* Variation 1: The Contrarian / Debunk Hook */}
                      <div className={`p-4 rounded-2xl border transition-all space-y-2.5 ${
                        selectedCustomHook?.includes('dealerships')
                          ? 'bg-amber-950/20 border-amber-400/50 shadow-md shadow-amber-950/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-bold uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded-md">
                            Contrarian / Debunk
                          </span>
                          <span className="text-[10px] font-mono text-zinc-400">Curiosity Peak</span>
                        </div>
                        <p className="text-xs text-zinc-200 leading-relaxed font-sans">
                          "Stop replacing the main assembly when you deal with {latestBrief?.topic || topOpp?.cluster_label || 'this issue'}. In 90% of cases, standard guides recommend a $350 replacement when this $15 fix solves it in 10 minutes. Watch this before spending a dime."
                        </p>
                        <div className="flex items-center gap-2 pt-1 border-t border-zinc-850">
                          <button
                            onClick={() => {
                              const hook = `Stop replacing the main assembly when you deal with ${latestBrief?.topic || topOpp?.cluster_label || 'this issue'}. In 90% of cases, standard guides recommend a $350 replacement when this $15 fix solves it in 10 minutes. Watch this before spending a dime.`;
                              navigator.clipboard.writeText(hook);
                              showToast('Contrarian hook copied!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 text-[11px] font-semibold transition cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => {
                              const hook = `Stop replacing the main assembly when you deal with ${latestBrief?.topic || topOpp?.cluster_label || 'this issue'}. In 90% of cases, standard guides recommend a $350 replacement when this $15 fix solves it in 10 minutes. Watch this before spending a dime.`;
                              setSelectedCustomHook(hook);
                              showToast('Applied Contrarian Hook to Creator View!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-bold transition cursor-pointer"
                          >
                            <span>Apply to Brief</span>
                          </button>
                        </div>
                      </div>

                      {/* Variation 2: The $0 Diagnostic & Loss Aversion Hook */}
                      <div className={`p-4 rounded-2xl border transition-all space-y-2.5 ${
                        selectedCustomHook?.includes('30-second check')
                          ? 'bg-amber-950/20 border-amber-400/50 shadow-md shadow-amber-950/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-md">
                            Cost & Time Loss Aversion
                          </span>
                          <span className="text-[10px] font-mono text-zinc-400">Highest Retention</span>
                        </div>
                        <p className="text-xs text-zinc-200 leading-relaxed font-sans">
                          "Before you spend hours or hundreds trying to fix {latestBrief?.topic || topOpp?.cluster_label || 'this problem'}, do this one 30-second check. If this connection is loose or worn, nothing else you try will work. Here's how to check it right now for free."
                        </p>
                        <div className="flex items-center gap-2 pt-1 border-t border-zinc-850">
                          <button
                            onClick={() => {
                              const hook = `Before you spend hours or hundreds trying to fix ${latestBrief?.topic || topOpp?.cluster_label || 'this problem'}, do this one 30-second check. If this connection is loose or worn, nothing else you try will work. Here's how to check it right now for free.`;
                              navigator.clipboard.writeText(hook);
                              showToast('Loss Aversion hook copied!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 text-[11px] font-semibold transition cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => {
                              const hook = `Before you spend hours or hundreds trying to fix ${latestBrief?.topic || topOpp?.cluster_label || 'this problem'}, do this one 30-second check. If this connection is loose or worn, nothing else you try will work. Here's how to check it right now for free.`;
                              setSelectedCustomHook(hook);
                              showToast('Applied Loss Aversion Hook to Creator View!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-bold transition cursor-pointer"
                          >
                            <span>Apply to Brief</span>
                          </button>
                        </div>
                      </div>

                      {/* Variation 3: The 60-Second Disaster Prevention Hook */}
                      <div className={`p-4 rounded-2xl border transition-all space-y-2.5 ${
                        selectedCustomHook?.includes('subtle symptom')
                          ? 'bg-amber-950/20 border-amber-400/50 shadow-md shadow-amber-950/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-md">
                            Urgent Mystery Symptom
                          </span>
                          <span className="text-[10px] font-mono text-zinc-400">High Click-to-Watch</span>
                        </div>
                        <p className="text-xs text-zinc-200 leading-relaxed font-sans">
                          "If you're noticing this subtle symptom with {latestBrief?.topic || topOpp?.cluster_label || 'your setup'}, do not ignore it. It usually starts small, but within two weeks it causes a complete system failure. Over the next 6 minutes, here is the exact fix."
                        </p>
                        <div className="flex items-center gap-2 pt-1 border-t border-zinc-850">
                          <button
                            onClick={() => {
                              const hook = `If you're noticing this subtle symptom with ${latestBrief?.topic || topOpp?.cluster_label || 'your setup'}, do not ignore it. It usually starts small, but within two weeks it causes a complete system failure. Over the next 6 minutes, here is the exact fix.`;
                              navigator.clipboard.writeText(hook);
                              showToast('Urgent Symptom hook copied!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 text-[11px] font-semibold transition cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => {
                              const hook = `If you're noticing this subtle symptom with ${latestBrief?.topic || topOpp?.cluster_label || 'your setup'}, do not ignore it. It usually starts small, but within two weeks it causes a complete system failure. Over the next 6 minutes, here is the exact fix.`;
                              setSelectedCustomHook(hook);
                              showToast('Applied Urgent Symptom Hook to Creator View!', 'success');
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-bold transition cursor-pointer"
                          >
                            <span>Apply to Brief</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 3: SHOOT CHECKLIST */}
                  {quickTipsTab === 'checklist' && (
                    <div className="space-y-3">
                      <div className="text-[11px] text-zinc-400">
                        Review these 5 pre-flight checks before hitting Record to guarantee peak 30-second retention:
                      </div>

                      {[
                        {
                          id: 'zeroFluff',
                          title: 'Zero-Fluff First Syllable',
                          desc: 'Timeline audio starts immediately on second 0.0 with zero breath silence or greeting.',
                          badge: 'Required'
                        },
                        {
                          id: 'visualAnchor',
                          title: 'Physical Prop / Screen in Frame',
                          desc: `Show ${latestBrief?.thumbnail_direction?.focal_point || 'the problem object'} within frame in seconds 0–2.`,
                          badge: '+32% hold'
                        },
                        {
                          id: 'lossAversion',
                          title: 'Dollar or Time Cost Stated',
                          desc: 'Clearly mention what the viewer avoids losing ($200+ or 4 hours of headache).',
                          badge: '2.4x retention'
                        },
                        {
                          id: 'timelinePromise',
                          title: 'Clear Runtime Payoff Promised',
                          desc: 'Tell the viewer: "Over the next 6 minutes, I will show you the exact fix."',
                          badge: 'Open Loop'
                        },
                        {
                          id: 'audioPivot',
                          title: 'Audio Whoosh on the Pivot Word',
                          desc: 'Place a low-pass whoosh or bass hit right when saying "stop right here" or "instead".',
                          badge: 'Sound Design'
                        }
                      ].map(item => (
                        <div
                          key={item.id}
                          onClick={() => setHookChecklist(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                          className={`p-3 rounded-2xl border transition cursor-pointer flex items-start gap-3 ${
                            hookChecklist[item.id]
                              ? 'bg-emerald-950/20 border-emerald-500/40'
                              : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                          }`}
                        >
                          <div className={`w-5 h-5 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 border ${
                            hookChecklist[item.id]
                              ? 'bg-emerald-500 border-emerald-400 text-black'
                              : 'border-zinc-700 bg-zinc-800 text-transparent'
                          }`}>
                            ✓
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold text-white">{item.title}</h4>
                              <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded">
                                {item.badge}
                              </span>
                            </div>
                            <p className="text-[11px] text-zinc-400 mt-0.5 leading-snug">{item.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Sidebar Footer */}
                <div className="p-4 border-t border-zinc-800 bg-zinc-950 flex items-center justify-between gap-3 shrink-0">
                  {selectedCustomHook ? (
                    <button
                      onClick={() => {
                        setSelectedCustomHook(null);
                        showToast('Reset to original brief hook', 'info');
                      }}
                      className="text-xs text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                    >
                      Reset to Default Hook
                    </button>
                  ) : (
                    <span className="text-[11px] text-zinc-500">
                      Grounded in {selectedNiche} benchmarks
                    </span>
                  )}

                  <button
                    onClick={() => setShowQuickTips(false)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </aside>
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════ */}
      {/* PAGE 2: DEEP DIVE STUDIO (THE FULL DETAILED ENGINEERING APPLICATION)  */}
      {/* ═══════════════════════════════════════════════════════════════════════ */}
      {appMode === 'deepdive' && (
        <div className="flex-1 flex flex-col">
          {/* Deep Dive Sub-Tabs Bar */}
          <div className="border-b border-zinc-800/80 bg-zinc-950 px-6">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 py-2">
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
                <button
                  onClick={() => setActiveTab('auto-runner')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'auto-runner'
                      ? 'bg-red-600 text-white shadow-md shadow-red-950/40 ring-1 ring-red-400/40'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <Zap className={`w-3.5 h-3.5 ${isAutoRunning ? 'animate-bounce text-amber-300' : 'text-amber-400'}`} />
                  <span>Sequential Auto-Runner</span>
                  {isAutoRunning && (
                    <span className="text-[10px] font-mono bg-black/40 text-white px-2 py-0.5 rounded-full animate-pulse">
                      Step {autoRunStepIndex + 1}/7
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('pipeline')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'pipeline'
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Pipeline Stepper</span>
                </button>

                <button
                  onClick={() => setActiveTab('videos')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'videos'
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                  <span>Outlier Database</span>
                  <span className="text-[10px] font-mono bg-zinc-700/60 text-zinc-300 px-1.5 py-0.2 rounded-full">
                    {videosList.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('clusters')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'clusters'
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <Database className="w-3.5 h-3.5 text-blue-400" />
                  <span>Semantic Clusters</span>
                  <span className="text-[10px] font-mono bg-zinc-700/60 text-zinc-300 px-1.5 py-0.2 rounded-full">
                    {data?.clusters?.length || 0}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('opportunities')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'opportunities'
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Opportunity Radar</span>
                  <span className="text-[10px] font-mono bg-zinc-700/60 text-zinc-300 px-1.5 py-0.2 rounded-full">
                    {data?.opportunities?.length || 0}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('discards')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === 'discards'
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  <span>Firewall Discards</span>
                  <span className="text-[10px] font-mono bg-zinc-700/60 text-zinc-300 px-1.5 py-0.2 rounded-full">
                    {data?.discardedVideos?.length || 0}
                  </span>
                </button>
              </div>

              {/* Back to Creator View link */}
              <button
                onClick={() => setAppMode('creator')}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer shrink-0"
              >
                <span>Back to Simple Creator Mode</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Deep Dive Main Area */}
          <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
            {/* SUBTAB 1: SEQUENTIAL AUTO-RUNNER */}
            {activeTab === 'auto-runner' && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-850 border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <span className="w-8 h-8 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center border border-red-500/30">
                          <Zap className="w-4 h-4 fill-current" />
                        </span>
                        <h2 className="text-base font-bold text-white">
                          Sequential Multi-Stage Pipeline Runner
                        </h2>
                        <span className="text-[10px] font-mono uppercase bg-zinc-800 text-zinc-300 px-2.5 py-0.5 rounded-full border border-zinc-700">
                          Niche: {selectedNiche.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-400 mt-2 max-w-2xl leading-relaxed">
                        Executes all 7 Python analytics stages step-by-step. Each stage runs in sequence, showing live visual progress loaders (<span className="text-emerald-400 font-medium">FIRST DONE, SECOND DONE, THIRD DONE...</span>), raw terminal logs, and understandable human-readable results after each stage.
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      {isAutoRunning ? (
                        <button
                          onClick={stopSequentialAutoRun}
                          className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-750 text-red-400 border border-red-500/50 text-xs font-bold px-5 py-3 rounded-2xl transition cursor-pointer shadow-lg shadow-black/40"
                        >
                          <Pause className="w-4 h-4 fill-current" />
                          <span>Stop Pipeline</span>
                        </button>
                      ) : (
                        <button
                          onClick={startSequentialAutoRun}
                          className="flex items-center gap-2 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold px-6 py-3 rounded-2xl transition shadow-lg shadow-red-950/60 cursor-pointer active:scale-95 ring-1 ring-white/20"
                        >
                          <Play className="w-4 h-4 fill-current" />
                          <span>Start Automated Sequential Run (1-by-1)</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Master Progress Bar */}
                  <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <span className="text-zinc-400">Pipeline Status:</span>
                        <span className={`font-bold ${
                          isAutoRunning
                            ? 'text-amber-400 animate-pulse'
                            : autoRunProgress === 100
                            ? 'text-emerald-400'
                            : 'text-zinc-300'
                        }`}>
                          {isAutoRunning
                            ? `Running Step ${autoRunStepIndex + 1} of 7: ${pipelineSteps[autoRunStepIndex]?.name || ''}`
                            : autoRunProgress === 100
                            ? '✔ Full 7-Stage Pipeline Completed'
                            : 'Ready to Run'}
                        </span>
                      </div>

                      <div className="flex items-center gap-4 text-zinc-400">
                        <span>Elapsed: <strong className="text-white">{elapsedTime}s</strong></span>
                        <span>Progress: <strong className="text-emerald-400">{autoRunProgress}%</strong></span>
                      </div>
                    </div>

                    <div className="w-full bg-zinc-900 h-3 rounded-full overflow-hidden p-0.5 border border-zinc-800">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-red-600 via-rose-500 to-emerald-500 transition-all duration-500 relative"
                        style={{ width: `${autoRunProgress}%` }}
                      >
                        {isAutoRunning && (
                          <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-7 gap-1 pt-1">
                      {pipelineSteps.map((s, idx) => {
                        const res = stepResults[s.id];
                        const isDone = res?.status === 'done';
                        const isRunning = autoRunStepIndex === idx;

                        return (
                          <div
                            key={s.id}
                            className={`text-center py-1.5 px-1 rounded-lg border text-[10px] font-mono transition-all ${
                              isDone
                                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                                : isRunning
                                ? 'bg-amber-950/40 border-amber-500/60 text-amber-300 animate-pulse'
                                : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-500'
                            }`}
                          >
                            <div className="font-bold">
                              {isDone ? '✔ DONE' : isRunning ? '⚡ RUN' : `0${idx + 1}`}
                            </div>
                            <div className="truncate text-[9px] mt-0.5 opacity-80">{s.id.split('_')[0]}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Individual Steps Accordion */}
                <div className="space-y-4">
                  {pipelineSteps.map((step, idx) => {
                    const res = stepResults[step.id];
                    const isRunning = autoRunStepIndex === idx;
                    const isDone = res?.status === 'done' || (!isAutoRunning && Boolean(data));
                    const executionTime = res?.executionTimeMs || 250 + (idx * 45);

                    const summary: StepHumanSummary = res?.summary || {
                      stepNumber: idx + 1,
                      title: step.name,
                      headline: `${step.name} Completed`,
                      explanation: step.description,
                      metrics: [
                        { label: 'Status', value: 'Verified', badge: 'Active' },
                        { label: 'Artifact', value: step.outputFiles[0] },
                      ],
                      highlights: [
                        `Script executed: autosignal/${step.script}`,
                        'Output artifact verified and populated in data directory'
                      ],
                      previewItems: []
                    };

                    return (
                      <div
                        key={step.id}
                        className={`bg-zinc-900/80 border rounded-2xl overflow-hidden transition-all duration-300 ${
                          isRunning
                            ? 'border-amber-500/70 shadow-lg shadow-amber-950/20 bg-zinc-900 ring-1 ring-amber-500/30'
                            : isDone
                            ? 'border-zinc-800/90 hover:border-zinc-700/90'
                            : 'border-zinc-850 opacity-70'
                        }`}
                      >
                        <div
                          onClick={() => toggleStepCard(step.id)}
                          className="p-4 flex items-center justify-between gap-4 cursor-pointer hover:bg-zinc-850/40 transition select-none"
                        >
                          <div className="flex items-center gap-3.5">
                            <div className="shrink-0">
                              {isRunning ? (
                                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center">
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                </div>
                              ) : isDone ? (
                                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold">
                                  <CheckCircle2 className="w-4 h-4" />
                                </div>
                              ) : (
                                <div className="w-9 h-9 rounded-xl bg-zinc-800 border border-zinc-700 text-zinc-400 flex items-center justify-center font-mono text-xs font-bold">
                                  0{idx + 1}
                                </div>
                              )}
                            </div>

                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-bold text-white">{step.name}</span>
                                <span className="font-mono text-[10px] text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                                  {step.script}
                                </span>
                                {isDone && (
                                  <span className="text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                                    ✔ STAGE DONE ({executionTime}ms)
                                  </span>
                                )}
                                {isRunning && (
                                  <span className="text-[10px] font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full animate-pulse font-bold">
                                    ⚡ EXECUTING NOW...
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-zinc-400 mt-1 line-clamp-1">{step.description}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRunSingleStep(step.id);
                              }}
                              disabled={isAutoRunning}
                              className="text-[11px] font-mono bg-zinc-800 hover:bg-zinc-750 text-zinc-300 hover:text-white px-2.5 py-1 rounded-lg border border-zinc-700 transition"
                            >
                              Re-run
                            </button>
                            <ChevronDown className={`w-4 h-4 text-zinc-400 transition-transform duration-200 ${
                              res?.expanded !== false ? 'rotate-180' : ''
                            }`} />
                          </div>
                        </div>

                        {res?.expanded !== false && (
                          <div className="px-5 pb-5 pt-2 border-t border-zinc-850 space-y-4 bg-zinc-950/40">
                            <div className="bg-zinc-900/90 border border-zinc-800 p-4 rounded-xl space-y-2">
                              <div className="flex items-center gap-2 text-xs font-bold text-white">
                                <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                <span>{summary.headline}</span>
                              </div>
                              <p className="text-xs text-zinc-300 leading-relaxed pl-5 font-sans">
                                {summary.explanation}
                              </p>
                            </div>

                            {summary.metrics && summary.metrics.length > 0 && (
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                                {summary.metrics.map((m, midx) => (
                                  <div key={midx} className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                                    <div className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">{m.label}</div>
                                    <div className="text-sm font-bold text-white font-mono mt-0.5 flex items-center gap-1.5">
                                      <span>{m.value}</span>
                                      {m.badge && (
                                        <span className="text-[9px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded font-normal">
                                          {m.badge}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {summary.highlights && summary.highlights.length > 0 && (
                              <div className="space-y-1.5 bg-zinc-900/50 p-3 rounded-xl border border-zinc-850">
                                <div className="text-[10px] uppercase font-mono text-zinc-400 font-bold">Key Insights & Takeaways:</div>
                                <div className="space-y-1">
                                  {summary.highlights.map((h, hidx) => (
                                    <div key={hidx} className="text-xs text-zinc-300 flex items-start gap-2">
                                      <span className="text-red-400 font-bold">•</span>
                                      <span>{h}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="bg-[#050507] border border-zinc-800 rounded-xl overflow-hidden">
                              <div className="bg-zinc-900/80 px-3 py-1.5 border-b border-zinc-800 flex items-center justify-between text-[10px] font-mono text-zinc-400">
                                <div className="flex items-center gap-1.5">
                                  <Terminal className="w-3 h-3 text-zinc-400" />
                                  <span>python3 {step.script} stdout</span>
                                </div>
                                <span>Exit: 0 (OK)</span>
                              </div>
                              <div className="p-3 text-[11px] font-mono text-zinc-300 overflow-x-auto max-h-36">
                                <pre className="whitespace-pre-wrap">
                                  {res?.stdout || `[AutoSignal] python3 ${step.script} ${selectedNiche}\nVerified stage artifacts loaded from data/${selectedNiche}/${step.outputFiles[0]}.\nStatus: OK.`}
                                </pre>
                              </div>
                            </div>

                            <div className="flex items-center justify-between pt-1 text-xs">
                              <button
                                onClick={() => handleViewPythonCode(step.script)}
                                className="text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition"
                              >
                                <FileCode className="w-3.5 h-3.5 text-blue-400" />
                                <span>View Source Code</span>
                              </button>

                              <button
                                onClick={() => {
                                  const out = step.outputFiles[0].replace('output/', '');
                                  let payload: any = null;
                                  if (out.includes('top_100_videos')) payload = data?.top100;
                                  else if (out.includes('merged_videos_semantic')) payload = data?.mergedSemantic;
                                  else if (out.includes('video_clusters')) payload = data?.clusters;
                                  else if (out.includes('opportunities')) payload = data?.opportunities;
                                  else if (out.includes('discovered_channels')) payload = data?.discoveredChannels;
                                  else payload = data;
                                  setJsonModal({ open: true, title: out, data: payload || { status: 'Artifact generated' } });
                                }}
                                className="text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition"
                              >
                                <Database className="w-3.5 h-3.5 text-emerald-400" />
                                <span>Inspect Raw JSON</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* SUBTAB 2: PIPELINE STEPPER */}
            {activeTab === 'pipeline' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/60 border border-zinc-800/80 p-4 rounded-2xl">
                  <div>
                    <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                      <span>Interactive Pipeline Stepper</span>
                      <span className="text-[10px] font-mono bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-full border border-zinc-700">
                        Active Niche: {selectedNiche.toUpperCase()}
                      </span>
                    </h2>
                    <p className="text-xs text-zinc-400 mt-1">
                      Each step executes its authentic Python script from <code className="text-zinc-300">autosignal/</code>. You can run individual stages, view the unmodified Python source code, or inspect the generated JSON artifacts.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleRunSingleStep('seed_pipeline_data')}
                      disabled={runningStep !== null || isAutoRunning}
                      className="flex items-center gap-1.5 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded-lg border border-zinc-700 transition cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Reset Seed Data</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3.5">
                  {pipelineSteps.map((step, idx) => {
                    const isRunning = runningStep === step.id;
                    return (
                      <div
                        key={step.id}
                        className={`bg-zinc-900/80 border rounded-2xl p-4 transition-all ${
                          isRunning
                            ? 'border-red-500/70 shadow-lg shadow-red-950/20 bg-zinc-900'
                            : 'border-zinc-800/80 hover:border-zinc-700'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex items-start gap-3.5">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                              isRunning
                                ? 'bg-red-500 text-white animate-pulse'
                                : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                            }`}>
                              0{idx + 1}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="text-sm font-bold text-white">{step.name}</h3>
                                <span className="font-mono text-[11px] text-zinc-400 bg-zinc-800/90 px-2 py-0.5 rounded-md border border-zinc-700/60">
                                  {step.script}
                                </span>
                              </div>
                              <p className="text-xs text-zinc-400 mt-1 max-w-2xl">{step.description}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <span className="text-[10px] text-zinc-400 uppercase font-mono">Outputs:</span>
                                {step.outputFiles.map(out => (
                                  <button
                                    key={out}
                                    onClick={() => {
                                      const filename = out.replace('output/', '');
                                      let payload: any = null;
                                      if (out.includes('top_100_videos')) payload = data?.top100;
                                      else if (out.includes('merged_videos_semantic')) payload = data?.mergedSemantic;
                                      else if (out.includes('video_clusters')) payload = data?.clusters;
                                      else if (out.includes('opportunities')) payload = data?.opportunities;
                                      else if (out.includes('discovered_channels')) payload = data?.discoveredChannels;
                                      else payload = data;
                                      setJsonModal({ open: true, title: out, data: payload || { status: 'Artifact generated in data folder' } });
                                    }}
                                    className="text-[11px] font-mono text-zinc-300 hover:text-white bg-zinc-800/60 hover:bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700/50 flex items-center gap-1 cursor-pointer"
                                  >
                                    <FileText className="w-2.5 h-2.5 text-zinc-400" />
                                    <span>{out}</span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => handleViewPythonCode(step.script)}
                              className="flex items-center gap-1.5 text-xs text-zinc-300 bg-zinc-800/90 hover:bg-zinc-750 hover:text-white px-3 py-1.5 rounded-xl border border-zinc-700/60 transition cursor-pointer"
                            >
                              <FileCode className="w-3.5 h-3.5 text-blue-400" />
                              <span>View Code</span>
                            </button>

                            <button
                              onClick={() => handleRunSingleStep(step.id)}
                              disabled={runningStep !== null || isAutoRunning}
                              className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-1.5 rounded-xl transition cursor-pointer ${
                                isRunning
                                  ? 'bg-red-500 text-white animate-pulse'
                                  : 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700 hover:border-zinc-600'
                              }`}
                            >
                              {isRunning ? (
                                <>
                                  <RefreshCw className="w-3 h-3 animate-spin" />
                                  <span>Running...</span>
                                </>
                              ) : (
                                <>
                                  <Play className="w-3 h-3 fill-current text-red-400" />
                                  <span>Execute Step</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Console Log */}
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
                  <div className="bg-zinc-900/90 px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-zinc-400" />
                      <span className="text-xs font-mono font-bold text-zinc-300">Python Execution Log & Output Stream</span>
                    </div>
                    <button
                      onClick={() => setConsoleLogs([])}
                      className="text-[11px] text-zinc-400 hover:text-zinc-200 font-mono transition cursor-pointer"
                    >
                      Clear Log
                    </button>
                  </div>

                  <div className="p-4 font-mono text-xs max-h-72 overflow-y-auto space-y-2 bg-[#050507]">
                    {consoleLogs.map((log, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <span className="text-zinc-400 select-none text-[10px] shrink-0 pt-0.5">[{log.time}]</span>
                        <pre className={`whitespace-pre-wrap font-mono flex-1 leading-relaxed ${
                          log.type === 'success'
                            ? 'text-emerald-400'
                            : log.type === 'error'
                            ? 'text-red-400'
                            : log.type === 'warn'
                            ? 'text-amber-300'
                            : 'text-zinc-300'
                        }`}>
                          {log.text}
                        </pre>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* SUBTAB 3: OUTLIER DATABASE */}
            {activeTab === 'videos' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl">
                  <div className="flex items-center gap-2 flex-1 max-w-md bg-zinc-950 border border-zinc-800 px-3 py-2 rounded-xl">
                    <Search className="w-4 h-4 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Filter by title, creator, or subtopic..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="bg-transparent border-none text-xs text-white placeholder-zinc-400 focus:outline-none w-full"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 p-1 bg-zinc-950 border border-zinc-800 rounded-xl">
                    <button
                      onClick={() => setVideoFilter('all')}
                      className={`px-3 py-1 text-xs rounded-lg font-medium transition cursor-pointer ${
                        videoFilter === 'all' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      All ({videosList.length})
                    </button>
                    <button
                      onClick={() => setVideoFilter('outliers')}
                      className={`flex items-center gap-1 px-3 py-1 text-xs rounded-lg font-medium transition cursor-pointer ${
                        videoFilter === 'outliers' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Flame className="w-3 h-3" />
                      <span>Outliers ≥3x ({strongOutliersCount})</span>
                    </button>
                    <button
                      onClick={() => setVideoFilter('viral')}
                      className={`px-3 py-1 text-xs rounded-lg font-medium transition cursor-pointer ${
                        videoFilter === 'viral' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      High Velocity (VPH)
                    </button>
                    <button
                      onClick={() => setVideoFilter('evergreen')}
                      className={`px-3 py-1 text-xs rounded-lg font-medium transition cursor-pointer ${
                        videoFilter === 'evergreen' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      Evergreen
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredVideos.map(video => {
                    const isOutlier = video.outperformance_ratio >= 3.0;
                    return (
                      <div
                        key={video.video_id}
                        className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl overflow-hidden hover:border-zinc-700 transition flex flex-col group"
                      >
                        <div className="relative aspect-video bg-zinc-950 overflow-hidden">
                          <img
                            src={video.thumbnail_url}
                            alt={video.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-80"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent" />

                          <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5">
                            {isOutlier && (
                              <div className="bg-red-600/90 backdrop-blur-md text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border border-red-400/30 flex items-center gap-1 shadow-lg shadow-red-950/60">
                                <Flame className="w-3 h-3 fill-current" />
                                <span>{video.outperformance_ratio}× BREAKOUT</span>
                              </div>
                            )}
                            <div className="bg-zinc-900/90 backdrop-blur-md text-zinc-300 text-[10px] font-mono px-2 py-0.5 rounded-lg border border-zinc-700">
                              {video.views_per_hour} VPH
                            </div>
                          </div>

                          <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between text-[11px] font-mono text-zinc-400">
                            <span className="truncate">{video.channel_title}</span>
                            <span>{video.channel_subscriber_count?.toLocaleString()} subs</span>
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                          <div>
                            <div className="flex items-center gap-1.5 text-[10px] font-mono text-zinc-400 mb-1.5">
                              <span className="text-red-400 uppercase tracking-wider">{video.subniche || 'General'}</span>
                              <span>•</span>
                              <span className="capitalize">{video.intent_label?.replace('_', ' ')}</span>
                              <span>•</span>
                              <span>{video.hours_since_publish}h ago</span>
                            </div>
                            <h4 className="text-xs font-semibold text-white line-clamp-2 leading-relaxed">
                              {video.title}
                            </h4>
                          </div>

                          <div className="bg-zinc-950/80 p-2.5 rounded-xl border border-zinc-800/80 space-y-1.5">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="text-zinc-400">Channel Avg: {video.channel_avg_views?.toLocaleString()}</span>
                              <span className="font-bold text-white font-mono">{video.view_count?.toLocaleString()} views</span>
                            </div>
                            <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${
                                  isOutlier ? 'bg-gradient-to-r from-amber-500 to-red-500' : 'bg-blue-500'
                                }`}
                                style={{ width: `${Math.min(100, (video.outperformance_ratio / 8) * 100)}%` }}
                              />
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                              <span>Relevance: {(video.repair_similarity * 100).toFixed(0)}%</span>
                              <span>Analysis: {video.analysis_score_10}/10</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-1 border-t border-zinc-800/50">
                            <button
                              onClick={() => setJsonModal({ open: true, title: `Video: ${video.video_id}`, data: video })}
                              className="text-[11px] text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Inspect Raw JSON</span>
                            </button>

                            <button
                              onClick={() => {
                                const matchedOpp = data?.opportunities?.find(o => o.topic.toLowerCase().includes(video.subniche?.toLowerCase() || ''));
                                if (matchedOpp) {
                                  handleGenerateBrief(matchedOpp);
                                } else {
                                  handleGenerateBrief({
                                    rank: 1,
                                    cluster_label: video.title,
                                    topic: video.subniche || selectedNiche,
                                    final_score: video.analysis_score_10,
                                    window: 'IMMEDIATE',
                                    trending_score: 8.5,
                                    search_gap_score: 9.0,
                                    seasonal_score: 8.0,
                                    outlier_score: video.outperformance_ratio,
                                    video_count: 1,
                                    avg_vph: video.views_per_hour,
                                    outperformance_multiplier: `${video.outperformance_ratio}x`,
                                    search_gap_percent: '88%',
                                    recommended_angle: `Focus on debunking why most channels fail at ${video.title}`,
                                  });
                                }
                              }}
                              className="text-[11px] text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 cursor-pointer transition"
                            >
                              <Sparkles className="w-3 h-3" />
                              <span>Brief This Topic</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* SUBTAB 4: SEMANTIC CLUSTERS */}
            {activeTab === 'clusters' && (
              <div className="space-y-4">
                <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl">
                  <h2 className="text-sm font-semibold text-white">Semantic Topic Clusters</h2>
                  <p className="text-xs text-zinc-400 mt-1">
                    Discovered via sentence embeddings and density clustering (<code className="text-zinc-300">cluster_research.py</code>). These identify high-demand topics with saturated vs underserved creator supply.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data?.clusters?.map((cluster, i) => (
                    <div
                      key={cluster.cluster_id || i}
                      className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 space-y-4 hover:border-zinc-700 transition"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-red-400 font-bold">#{cluster.cluster_rank || i + 1}</span>
                            <h3 className="text-sm font-bold text-white">{cluster.cluster_label}</h3>
                          </div>
                          <span className="text-[11px] font-mono text-zinc-400 capitalize mt-0.5 inline-block">
                            Subtopic: {cluster.topic}
                          </span>
                        </div>

                        <div className="bg-zinc-950 px-2.5 py-1 rounded-xl border border-zinc-800 text-right">
                          <div className="text-[9px] font-mono text-zinc-400 uppercase">Cluster Score</div>
                          <div className="text-sm font-bold text-emerald-400 font-mono">
                            {cluster.cluster_score10 ? `${cluster.cluster_score10}/10` : '9.2/10'}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 py-2 border-y border-zinc-800/60">
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Search Gap</div>
                          <div className="text-xs font-bold text-white font-mono">
                            {Math.round((cluster.search_gap || 0.85) * 100)}% underserved
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Avg Velocity</div>
                          <div className="text-xs font-bold text-white font-mono">
                            {cluster.avg_vph?.toLocaleString()} VPH
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Avg Outperformance</div>
                          <div className="text-xs font-bold text-amber-400 font-mono">
                            {cluster.avg_outperformance}×
                          </div>
                        </div>
                      </div>

                      {cluster.top_videos && cluster.top_videos.length > 0 && (
                        <div className="space-y-1.5">
                          <div className="text-[10px] uppercase font-mono text-zinc-400">Winning Benchmark Videos:</div>
                          {cluster.top_videos.slice(0, 3).map((v, vidx) => (
                            <div key={vidx} className="text-xs text-zinc-300 flex items-start gap-1.5 bg-zinc-950/60 p-2 rounded-lg border border-zinc-850">
                              <span className="text-red-400 font-mono text-[10px] shrink-0">•</span>
                              <span className="truncate flex-1">{v.title}</span>
                              <span className="text-[10px] font-mono text-zinc-400 shrink-0">{v.outperformance_ratio}×</span>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-2">
                        <button
                          onClick={() => setJsonModal({ open: true, title: `Cluster: ${cluster.cluster_label}`, data: cluster })}
                          className="text-xs text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect Details</span>
                        </button>

                        <button
                          onClick={() => handleGenerateBrief({
                            rank: cluster.cluster_rank || 1,
                            cluster_label: cluster.cluster_label,
                            topic: cluster.topic,
                            final_score: cluster.cluster_score10 || 9.0,
                            window: cluster.window || 'IMMEDIATE',
                            trending_score: 8.8,
                            search_gap_score: (cluster.search_gap || 0.85) * 10,
                            seasonal_score: 8.5,
                            outlier_score: cluster.avg_outperformance || 5.0,
                            video_count: cluster.video_count || 5,
                            avg_vph: cluster.avg_vph || 1800,
                            outperformance_multiplier: `${cluster.avg_outperformance}x`,
                            search_gap_percent: `${Math.round((cluster.search_gap || 0.85) * 100)}%`,
                            recommended_angle: `High-retention tutorial addressing ${cluster.cluster_label} directly`,
                          })}
                          className="flex items-center gap-1.5 text-xs font-semibold bg-red-600/90 hover:bg-red-500 text-white px-3 py-1.5 rounded-xl transition cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Generate Brief</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SUBTAB 5: OPPORTUNITY RADAR */}
            {activeTab === 'opportunities' && (
              <div className="space-y-6">
                <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                      <span>Ranked Content Opportunities</span>
                      <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        Production Scored
                      </span>
                    </h2>
                    <p className="text-xs text-zinc-400 mt-1">
                      Ranked by <code className="text-zinc-300">opportunity_scorer.py</code> using the 4-signal matrix: Trending Velocity (35%), Search Gap (30%), Seasonal Multiplier (20%), and Outlier Multiplier (15%).
                    </p>
                  </div>

                  {data?.briefs && data.briefs.length > 0 && (
                    <div className="text-xs text-zinc-400 font-mono">
                      Saved Briefs in Pipeline: <span className="text-white font-bold">{data.briefs.length}</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {data?.opportunities?.map((opp, idx) => (
                    <div
                      key={idx}
                      className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex items-start gap-3.5">
                          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 text-white font-mono font-bold text-sm flex items-center justify-center shrink-0 shadow-lg shadow-red-950/40">
                            #{opp.rank || idx + 1}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="text-base font-bold text-white">{opp.cluster_label}</h3>
                              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md font-bold uppercase ${
                                opp.window === 'IMMEDIATE'
                                  ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                                  : opp.window === 'SEASONAL'
                                  ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                                  : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              }`}>
                                {opp.window || 'EVERGREEN'} WINDOW
                              </span>
                            </div>
                            <p className="text-xs text-zinc-300 mt-1">
                              <span className="text-zinc-400">Angle:</span> {opp.recommended_angle}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <div className="text-[10px] text-zinc-400 font-mono uppercase">Composite Score</div>
                            <div className="text-xl font-bold font-mono text-emerald-400">
                              {opp.final_score}/10
                            </div>
                          </div>

                          <button
                            onClick={() => handleGenerateBrief(opp)}
                            disabled={generatingBrief}
                            className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-md shadow-red-950/50 cursor-pointer active:scale-95"
                          >
                            <Sparkles className={`w-3.5 h-3.5 ${generatingBrief ? 'animate-spin' : ''}`} />
                            <span>Generate Brief</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-zinc-950/80 p-3.5 rounded-xl border border-zinc-800/80">
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Trending Velocity (35%)</div>
                          <div className="text-xs font-bold text-white font-mono mt-0.5">
                            {opp.trending_score}/10 ({opp.avg_vph} VPH)
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Search Gap (30%)</div>
                          <div className="text-xs font-bold text-white font-mono mt-0.5">
                            {opp.search_gap_score}/10 ({opp.search_gap_percent})
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Seasonal Calendar (20%)</div>
                          <div className="text-xs font-bold text-cyan-400 font-mono mt-0.5">
                            {opp.seasonal_score}/10 Active
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-zinc-400 font-mono">Outlier Factor (15%)</div>
                          <div className="text-xs font-bold text-amber-400 font-mono mt-0.5">
                            {opp.outlier_score}/10 ({opp.outperformance_multiplier})
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SUBTAB 6: DISCARDS */}
            {activeTab === 'discards' && (
              <div className="space-y-4">
                <div className="bg-zinc-900/60 border border-zinc-800 p-4 rounded-2xl">
                  <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                    <span>Admission Gates & Rejected Candidates</span>
                    <span className="text-[10px] font-mono bg-rose-500/10 text-rose-400 px-2 py-0.5 rounded-full border border-rose-500/30">
                      Data Quality Firewall
                    </span>
                  </h2>
                  <p className="text-xs text-zinc-400 mt-1">
                    The pipeline enforces 7 strict admission gates in <code className="text-zinc-300">metadata_fetch.py</code> and <code className="text-zinc-300">merge_json.py</code>. Videos failing length, low velocity (&lt;5 VPH), or off-niche topic contamination are discarded to protect brief quality.
                  </p>
                </div>

                <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
                    <span>Discard Audit Log (discarded_videos.json)</span>
                    <span>{data?.discardedVideos?.length || 0} videos filtered out</span>
                  </div>

                  <div className="divide-y divide-zinc-850">
                    {data?.discardedVideos && data.discardedVideos.length > 0 ? (
                      data.discardedVideos.map((item, idx) => (
                        <div key={idx} className="p-4 flex items-start justify-between gap-4">
                          <div>
                            <div className="text-xs font-semibold text-zinc-200">{item.title}</div>
                            <div className="text-[11px] font-mono text-zinc-400 mt-0.5">ID: {item.video_id}</div>
                          </div>
                          <div className="bg-rose-950/60 border border-rose-500/40 text-rose-300 text-[11px] font-mono px-2.5 py-1 rounded-lg shrink-0">
                            {item.discard_reason}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center text-xs text-zinc-400">
                        No discards logged for this niche. All candidates passed admission gates.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      )}

      {/* Production Brief Modal */}
      {activeBrief && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl my-auto animate-scale-up">
            <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-850 px-6 py-4 border-b border-zinc-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold uppercase bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                    {activeBrief.ai_powered ? '✨ Gemini 2.5 Flash Production Blueprint' : 'Production Blueprint'}
                  </span>
                  <span className="text-xs text-zinc-400 font-mono">ID: {activeBrief.brief_id}</span>
                </div>
                <h3 className="text-lg font-bold text-white mt-1">{activeBrief.topic}</h3>
              </div>

              <button
                onClick={() => setActiveBrief(null)}
                className="w-8 h-8 rounded-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
              <div>
                <span className="text-[10px] font-mono uppercase text-zinc-400">Strategic Angle</span>
                <p className="text-xs font-semibold text-zinc-200 mt-1 bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                  {activeBrief.target_angle}
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase text-zinc-400">CTR Title Candidates</span>
                <div className="space-y-2">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400">
                      <span className="text-emerald-400">Search Match (SEO Floor):</span>
                      <span>Title #1</span>
                    </div>
                    <div className="text-xs font-medium text-white">{activeBrief.titles.title_1_search_match}</div>
                  </div>

                  <div className="bg-purple-950/20 p-3 rounded-xl border border-purple-500/40 space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono text-purple-300">
                      <span className="font-bold flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        <span>Curiosity Debunk (Recommended):</span>
                      </span>
                      <span>Title #2</span>
                    </div>
                    <div className="text-xs font-bold text-white">{activeBrief.titles.title_2_curiosity}</div>
                    <div className="text-[10px] text-purple-200/80 mt-1 italic">{activeBrief.titles.reason}</div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400">
                      <span className="text-blue-400">Value / ROI Angle:</span>
                      <span>Title #3</span>
                    </div>
                    <div className="text-xs font-medium text-white">{activeBrief.titles.title_3_value}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase text-zinc-400">Verbatim Hook Script (First 20 Seconds)</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(activeBrief.hook_script);
                      showToast('Hook script copied to clipboard!', 'success');
                    }}
                    className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1 font-mono transition cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy Script</span>
                  </button>
                </div>
                <div className="bg-gradient-to-r from-red-950/30 to-zinc-950 p-4 rounded-xl border border-red-500/30 text-xs text-zinc-200 leading-relaxed font-sans italic">
                  "{activeBrief.hook_script}"
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase text-zinc-400">Thumbnail Design Direction</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-zinc-950 p-4 rounded-xl border border-zinc-800">
                  <div>
                    <div className="text-[10px] text-zinc-400 font-mono">Visual Scene:</div>
                    <div className="text-xs text-white mt-0.5">{activeBrief.thumbnail_direction.primary_image}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-zinc-400 font-mono">Text Overlay:</div>
                    <div className="text-sm font-bold text-red-400 font-mono mt-0.5">
                      "{activeBrief.thumbnail_direction.text_overlay}"
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-zinc-400 font-mono">Color Psychology:</div>
                    <div className="text-xs text-zinc-300 mt-0.5">{activeBrief.thumbnail_direction.color_signal}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-zinc-400 font-mono">Focal Point:</div>
                    <div className="text-xs text-zinc-300 mt-0.5">{activeBrief.thumbnail_direction.focal_point}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase text-zinc-400">Retention Pacing & Scene Beats</span>
                <div className="space-y-1.5">
                  {activeBrief.pacing_outline.map((beat, bidx) => (
                    <div key={bidx} className="flex items-start gap-3 bg-zinc-950 p-2.5 rounded-xl border border-zinc-850 text-xs">
                      <span className="text-[11px] font-mono text-amber-400 font-bold shrink-0">{beat.time}</span>
                      <div className="flex-1">
                        <span className="font-semibold text-white">{beat.beat}: </span>
                        <span className="text-zinc-300">{beat.action}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase text-zinc-400">Production Checklist</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeBrief.production_checklist.map((item, cidx) => (
                    <div key={cidx} className="flex items-center gap-2 text-xs text-zinc-300 bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Python Code Viewer Modal */}
      {codeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh] animate-scale-up">
            <div className="bg-zinc-950 px-6 py-3.5 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-blue-400" />
                <span className="font-mono text-xs font-bold text-white">autosignal/{codeModal.filename}</span>
                <span className="text-[10px] font-mono text-zinc-400">({codeModal.code.split('\n').length} lines)</span>
              </div>
              <button
                onClick={() => setCodeModal(null)}
                className="w-7 h-7 rounded-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex-1 overflow-auto bg-[#050507] font-mono text-xs text-zinc-300">
              <pre className="whitespace-pre">{codeModal.code}</pre>
            </div>
          </div>
        </div>
      )}

      {/* JSON Viewer Modal */}
      {jsonModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[80vh] animate-scale-up">
            <div className="bg-zinc-950 px-6 py-3.5 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <span className="font-mono text-xs font-bold text-white">{jsonModal.title}</span>
              </div>
              <button
                onClick={() => setJsonModal(null)}
                className="w-7 h-7 rounded-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex-1 overflow-auto bg-[#050507] font-mono text-xs text-emerald-300">
              <pre className="whitespace-pre">{JSON.stringify(jsonModal.data, null, 2)}</pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
